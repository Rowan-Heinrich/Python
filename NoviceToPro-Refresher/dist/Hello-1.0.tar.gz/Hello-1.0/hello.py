#hello.py
def hello():
    print("Hello, World!")

def test():
    hello()

if __name__ == '__main__': test()
